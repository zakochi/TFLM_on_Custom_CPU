#!/bin/bash

# ==========================================
# 參數設定
# ==========================================
BITSTREAM="hw/project_3/project_3.runs/impl_1/Computer.bit"
BAUD_RATE=115200

# ==========================================
# 1. 自動偵測 UART Port (USB0 或 USB1)
# ==========================================
UART_PORT=""
if [ -e "/dev/ttyUSB1" ]; then
    UART_PORT="/dev/ttyUSB1"
elif [ -e "/dev/ttyUSB0" ]; then
    UART_PORT="/dev/ttyUSB0"
else
    echo "錯誤: 找不到任何 USB UART 裝置 (/dev/ttyUSB0 或 1)！"
    echo "請確認 Windows 端已執行: usbipd attach --wsl --busid <BUSID>"
    exit 1
fi

echo ">>> 偵測到 UART Port: $UART_PORT"

# ==========================================
# 2. 執行燒錄
# ==========================================
echo ">>> [1/2] 開始燒錄 FPGA..."

cat << TCL_EOF > program_fpga.tcl
open_hw_manager
connect_hw_server
open_hw_target
set dev [lindex [get_hw_devices] 0]
current_hw_device \$dev
refresh_hw_device -update_hw_probes false \$dev
set_property PROGRAM.FILE {$BITSTREAM} \$dev
program_hw_devices \$dev
close_hw_manager
exit
TCL_EOF

vivado -mode batch -source program_fpga.tcl -nolog -nojournal > /dev/null

if [ $? -ne 0 ]; then
    echo "錯誤: 燒錄失敗。"
    exit 1
fi

echo ">>> [2/2] 燒錄成功！"

# ==========================================
# 3. 自動進入監聽模式 (使用 cat)
# ==========================================
echo ""
echo "=============================================="
echo "   正在監聽 $UART_PORT (Baud: $BAUD_RATE)"
echo "   >>> 現在請按下 FPGA 板子上的 RESET 鍵 <<<"
echo "   (若要離開請按 Ctrl + C)"
echo "=============================================="

# 設定 Baud Rate
stty -F $UART_PORT $BAUD_RATE raw -echo

# 讀取並顯示 (忽略之前的雜訊，重新讀取)
cat $UART_PORT
