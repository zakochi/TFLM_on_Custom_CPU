# ==========================================
# 設定區
# ==========================================
BITSTREAM="hw/project_3/project_3.runs/impl_1/Computer.bit"
BAUD_RATE=115200
# 硬體原始碼目錄 (用來檢查是否有修改)
HW_SRC_DIR="hw/src_rescue"

# 解除 stack 限制
ulimit -s unlimited

# ==========================================
# Phase 1: 軟體編譯 (Smart SW Build)
# ==========================================
echo "========================================"
echo "Step 1: 軟體編譯檢查"
echo "========================================"

if [ ! -d "sw/build" ]; then
    mkdir -p sw/build
fi

# [關鍵修正] Make 變數展開時序問題修復
# 如果是第一次執行(或剛 clean 過)，Make 在讀取時會找不到原始碼(因為還沒 copy)。
# 所以我們要強制分兩步走：
# 1. 先執行 prepare_tflm 把檔案搬過去。
# 2. 再執行主編譯，這時 Make 就能透過 find 抓到所有檔案了。

if [ ! -f "sw/build/micro_src/.tflm_ready" ]; then
    echo ">>> [系統偵測] 偵測到環境未初始化..."
    echo ">>> [1/2] 正在準備 TFLM 原始碼 (Copying Files)..."
    make -C sw prepare_tflm -j12
fi

# 執行正式編譯 (這時候檔案已經存在，Make 才能正確找到它們)
echo ">>> [2/2] 執行增量編譯..."
make -C sw -j12

if [ $? -ne 0 ]; then
    echo "錯誤: 軟體編譯失敗！"
    exit 1
fi

# ==========================================
# Phase 2: 硬體編譯決策 (Smart HW Build)
# ==========================================
echo ""
echo "========================================"
echo "Step 2: 硬體編譯決策"
echo "========================================"

NEED_VIVADO=false

# 檢查 1: Bitstream 是否存在？
if [ ! -f "$BITSTREAM" ]; then
    echo ">>> 狀態: 找不到 Bitstream，必須編譯。"
    NEED_VIVADO=true
else
    # 檢查 2: 軟體 Hex 是否比 Bitstream 新？ (代表軟體改了，要更新 BRAM)
    if [ "sw/build/imem.hex" -nt "$BITSTREAM" ] || [ "sw/build/dmem.hex" -nt "$BITSTREAM" ]; then
        echo ">>> 狀態: 軟體 (Hex) 已更新，需要重新封裝 Bitstream。"
        NEED_VIVADO=true
    fi

    # 檢查 3: 硬體 Verilog 是否比 Bitstream 新？
    for f in $HW_SRC_DIR/*; do
        if [ "$f" -nt "$BITSTREAM" ]; then
            echo ">>> 狀態: 硬體原始碼 ($f) 已修改，需要重新 Synthesis。"
            NEED_VIVADO=true
            break
        fi
    done
fi

if [ "$NEED_VIVADO" = false ]; then
    echo ">>> 狀態: 硬體與軟體皆未變更，Bitstream 已是最新。"
    echo ">>> 跳過 Vivado 編譯，直接進行燒錄！(省下 30 分鐘)"
else
    # ==========================================
    # 執行 Vivado 編譯
    # ==========================================
    echo ">>> 啟動 Vivado 進行編譯..."
    
    cd hw
    
    # 自動修復專案 (如果專案資料夾被刪除)
    if [ ! -d "project_3" ]; then
        echo "警告: 找不到 project_3，正在重建專案..."
        vivado -mode batch -source rescue.tcl -nolog -nojournal
    fi

    # 執行重建
    vivado -mode batch -source rebuild.tcl -nolog -nojournal

    if [ $? -ne 0 ]; then
        echo "錯誤: Bitstream 生成失敗。請檢查 hw 內的 Log。"
        cd ..
        exit 1
    fi
    cd ..
fi

# ==========================================
# Phase 3: 燒錄 FPGA
# ==========================================
echo ""
echo "========================================"
echo "Step 3: 燒錄 FPGA"
echo "========================================"

# 產生燒錄腳本
cat << TCL_PROGRAM > program_temp.tcl
open_hw_manager
connect_hw_server
open_hw_target
set dev [lindex [get_hw_devices] 0]
current_hw_device \$dev
refresh_hw_device -update_hw_probes false \$dev
set_property PROGRAM.FILE {$BITSTREAM} \$dev
program_hw_devices \$dev
close_hw_manager
exit
TCL_PROGRAM

vivado -mode batch -source program_temp.tcl -nolog -nojournal > /dev/null
rm program_temp.tcl

if [ $? -ne 0 ]; then
    echo "錯誤: 燒錄失敗 (可能是 USB 沒接好)。"
    exit 1
fi
echo ">>> 燒錄成功！"

# ==========================================
# Phase 4: UART 監聽
# ==========================================
echo ""
echo "========================================"
echo "Step 4: 啟動 UART 監聽"
echo "========================================"

UART_PORT=""
if [ -e "/dev/ttyUSB1" ]; then
    UART_PORT="/dev/ttyUSB1"
elif [ -e "/dev/ttyUSB0" ]; then
    UART_PORT="/dev/ttyUSB0"
fi

if [ -z "$UART_PORT" ]; then
    echo "錯誤: 找不到 USB UART。"
    exit 1
fi

echo ">>> 偵測到 Port: $UART_PORT"
echo ">>> 請按下 FPGA 的 RESET 鍵..."
echo "----------------------------------------------"

stty -F $UART_PORT $BAUD_RATE raw -echo cs8 -cstopb -parenb
cat $UART_PORT
EOF