#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <stdint.h>
#include <sys/time.h>

/* 宣告 linker.ld 裡面的符號 */
extern char _heap_start; /* Heap 的起始地址 */
extern char _stack_top;  /* Stack 的起始地址 (記憶體最頂端) */

/* * _sbrk: 系統呼叫，用來增加 Heap 大小
 * 這是 malloc() 底層會呼叫的函式。
 * * 對於你的 128KB D_MEM:
 * Heap 從 _heap_start 往上長
 * Stack 從 _stack_top 往下長
 * 我們必須確保兩者不相撞
 */
void *_sbrk(int incr) {
    static char *heap_end = 0;
    char *prev_heap_end;
    char *stack_ptr;

    /* 第一次呼叫時，初始化 heap_end 指向 _heap_start */
    if (heap_end == 0) {
        heap_end = &_heap_start;
    }

    prev_heap_end = heap_end;

    /* 取得目前的 Stack Pointer (sp) */
    __asm volatile ("mv %0, sp" : "=r"(stack_ptr));

    /* 檢查是否 Heap 撞到 Stack 了 */
    if (heap_end + incr > stack_ptr) {
        /* 記憶體不足 (OOM) */
        errno = ENOMEM;
        return (void *) -1;
    }

    heap_end += incr;
    return (void *) prev_heap_end;
}

/* * _exit: 程式結束時呼叫
 * 在嵌入式系統中，程式不該結束，所以進入無窮迴圈
 */
void _exit(int status) {
    (void)status; // 防止編譯器警告 unused variable
    while (1) {
        // 可以在這裡閃爍 LED 或是印出 "System Halted"
    }
}

/* ==========================================================
   檔案系統 Stub (因為沒有檔案系統，這些都是騙編譯器的)
   讓 printf 覺得自己在對一個終端機 (Terminal) 輸出
   ========================================================== */

/* _fstat: 查詢檔案狀態 */
int _fstat(int file, struct stat *st) {
    (void)file;
    st->st_mode = S_IFCHR; // 告訴 printf這是一個 "字元裝置" (如 Console)
    return 0;
}

/* _isatty: 查詢是否為終端機 */
int _isatty(int file) {
    // 1 代表是 Terminal (stdio, stdout, stderr)
    // 這很重要，會影響 printf 的緩衝行為 (Buffer behavior)
    return 1; 
}

/* _lseek: 檔案定位 */
int _lseek(int file, int ptr, int dir) {
    (void)file;
    (void)ptr;
    (void)dir;
    return 0; // UART 不能 seek
}

/* _close: 關閉檔案 */
int _close(int file) {
    (void)file;
    return -1; // 關閉失敗 (我們不能關閉 UART)
}

/* _getpid: 取得 Process ID */
int _getpid(void) {
    return 1;
}

/* _kill: 殺掉 Process */
int _kill(int pid, int sig) {
    (void)pid;
    (void)sig;
    errno = EINVAL;
    return -1;
}

/* * _gettimeofday: (選用) TFLM 效能測試可能會用到 
 * 如果你的 CPU 有實作 mcycle CSR，這個可以用來計時
 */
int _gettimeofday(struct timeval *tv, void *tz) {
    (void)tz;
    if (tv) {
        // 讀取 RISC-V 的 cycle counter (mcycle)
        // 注意：這假設你的 CPU 支援 CSR 指令且有計數器
        uint32_t cycles;
        __asm volatile ("csrr %0, mcycle" : "=r"(cycles));
        
        // 簡單假設 100MHz (1us = 100 cycles)
        // 這不是精確時間，但可以用來比較相對快慢
        tv->tv_sec = cycles / 100000000;
        tv->tv_usec = (cycles % 100000000) / 100;
    }
    return 0;
}
