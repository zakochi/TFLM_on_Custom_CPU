#!/bin/bash

# ==========================================
# 1. 自動搜尋最新的 Bitstream
# ==========================================
# 在 project_3 資料夾下搜尋 .bit 檔
BITSTREAM_PATH=$(find ./project_3 -name "*.bit" | head -n 1)

if [ -z "$BITSTREAM_PATH" ]; then
    echo "錯誤: 找不到任何 .bit 檔案！"
    echo "請先確認 Vivado 是否編譯成功 (run_all.sh)。"
    exit 1
fi

echo ">>> 偵測到 Bitstream: $BITSTREAM_PATH"

# UART 設定
UART_DEV="/dev/ttyUSB1" # 請確認你的裝置名稱
BAUD_RATE=115200

# ==========================================
# 2. 產生 Vivado 燒錄腳本
# ==========================================
cat << TCL_EOF > program_device.tcl
open_hw_manager
connect_hw_server
open_hw_target

if {[catch {set my_hw_device [lindex [get_hw_devices] 0]}]} {
    puts "錯誤: 找不到硬體裝置，請檢查 USB 連接！"
    exit
}

current_hw_device \$my_hw_device
refresh_hw_device -update_hw_probes false \$my_hw_device

set_property PROGRAM.FILE {$BITSTREAM_PATH} \$my_hw_device

puts "Starting Programming..."
program_hw_devices \$my_hw_device
refresh_hw_device \$my_hw_device
puts "Programming Done!"
exit
TCL_EOF

# ==========================================
# 3. 執行燒錄
# ==========================================
echo "正在燒錄..."
vivado -mode batch -source program_device.tcl -nolog -nojournal

if [ $? -ne 0 ]; then
    echo "燒錄失敗。"
    rm program_device.tcl
    exit 1
fi

rm program_device.tcl

# ==========================================
# 4. 啟動 UART
# ==========================================
echo ""
echo ">>> 燒錄成功！正在監聽 UART..."
echo ">>> 請按下 FPGA 上的 CPU RESET 按鈕 <<<"
echo ""

sudo stty -F $UART_DEV $BAUD_RATE raw -echo
cat $UART_DEV
